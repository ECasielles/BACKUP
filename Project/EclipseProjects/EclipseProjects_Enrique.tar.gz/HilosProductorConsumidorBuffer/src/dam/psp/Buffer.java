package dam.psp;

public interface Buffer {

	public int leer();
	public void escribir(int valor);
	public void mostrarEstado(String cadena);
	
}
