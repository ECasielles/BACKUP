package dam.psp;


public class HiloEscritura extends Thread {
	private ControladorFichero destino;
	private String contenido;
	
	public HiloEscritura(ControladorFichero cfich, String cadena) {
		destino = cfich;
		contenido = cadena;
	}
		
	@Override
	public void run() {
		destino.println(contenido);
		destino.close();
	}

}
