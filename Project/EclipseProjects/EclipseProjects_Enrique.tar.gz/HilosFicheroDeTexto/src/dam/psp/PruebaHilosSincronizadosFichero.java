package dam.psp;

//ARREGLARLO

public class PruebaHilosSincronizadosFichero {

	public static void main(String[] args) throws InterruptedException {
		ControladorFichero cf = new ControladorFichero("poema.txt");
		
		String parrafo1 = "¡Ser o no ser, esa es la cuestión! ¿Qué debe más dignamente optar....?";
		String parrafo2 = "En un lugar de La Mancha, de cuyo nombre no quiero acordarme...";
		String parrafo3 = "Quisiera ser pirata, no por el oro ni la plata, sino...";
		String parrafo4 = ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>";
		String parrafo5 = "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<";

		new HiloEscritura(cf, parrafo4).start();
		new HiloEscritura(cf, parrafo5).start();
		new HiloEscritura(cf, parrafo1).start();
		new HiloEscritura(cf, parrafo2).start();
		new HiloEscritura(cf, parrafo3).start();
		
		//cf.close();
		
		/*		
		// ojo con el objeto compartido
		HiloEscritura shakespeare = new HiloEscritura(cf, parrafo1);
		HiloEscritura cervantes = new HiloEscritura(cf, parrafo2);
		HiloEscritura calico = new HiloEscritura(cf, parrafo );

		shakespeare.addFrase(parrafo1);
		cervantes.addFrase(parrafo2);
		calico.addFrase(parrafo3);

		shakespeare.start();
		cervantes.start();
		calico.start();

		shakespeare.join();
		cervantes.join();
		calico.join();
		*/		
		
		System.out.println("Datos escritos con éxito");
	}

}
